package com.amity.bookstore.utility;

public enum NotificationType {
	ORDER, PAYMENT, DELIVERY, PROMOTION
}
