package com.amity.bookstore.utility;

public enum PaymentStatus {

	PENDING, SUCCESS, FAILED, CANCELLED
}
